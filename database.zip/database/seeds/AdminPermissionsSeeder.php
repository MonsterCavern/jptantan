<?php

use Illuminate\Database\Seeder;

class AdminPermissionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $permissions = [
            [
                'name'        => 'All permission',
                'slug'        => '*',
                'prifix'      => 'admin',
                'http_method' => '',
                'http_path'   => '*',
            ],
            [
                'name'        => 'Dashboard',
                'slug'        => 'dashboard',
                'prifix'      => 'admin',
                'http_method' => 'GET',
                'http_path'   => '/',
            ],
            [
                'name'        => 'Login',
                'slug'        => 'auth.login',
                'prifix'      => 'admin',
                'http_method' => '',
                'http_path'   => "/login\r\n/logout",
            ],
            [
                'name'        => 'User setting',
                'slug'        => 'auth.setting',
                'prifix'      => 'admin',
                'http_method' => 'GET,PUT',
                'http_path'   => '/setting',
            ],
            [
                'name'        => 'Auth management',
                'slug'        => 'auth.management',
                'prifix'      => 'admin',
                'http_method' => '',
                'http_path'   => "/roles\r\n/permissions\r\n/menu\r\n/logs",
            ],
            [
                'name'        => 'Home',
                'slug'        => 'index',
                'prifix'      => '',
                'http_method' => 'GET',
                'http_path'   => '/',
            ],
        ];
        
        DB::table('permissions')->insert($permissions);
    }
}
