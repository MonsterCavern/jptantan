<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLogsTable extends Migration
{

    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('logs_api', function (Blueprint $table) {
            $table->bigIncrements('id', true);
            $table->integer('own_id');
            $table->string('own_type', 16);
            
            $table->timestamp('timestamp')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->string('remote_addr', 64);
            $table->text('user_agent');
            $table->text('params');
            $table->string('method', 16);
            $table->text('name');
            $table->text('response');
            $table->integer('response_time')->default(0);
            $table->text('header');
        });
        
        Schema::create('logs_err_sql', function (Blueprint $table) {
            $table->bigIncrements('id', true);
            $table->integer('own_id');
            $table->string('own_type', 16);
            
            $table->timestamp('timestamp')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->string('remote_addr', 64);
            $table->text('user_agent');
            $table->text('params');
            $table->string('method', 16);
            $table->text('name');
            $table->text('response');
            $table->integer('response_time')->default(0);
            $table->text('header');
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('logs_api');
        Schema::dropIfExists('logs_err_sql');
    }
}
